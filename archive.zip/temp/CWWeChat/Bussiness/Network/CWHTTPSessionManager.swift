//
//  CWHTTPSessionManager.swift
//  CWXMPPChat
//
//  Created by chenwei on 16/6/3.
//  Copyright © 2016年 chenwei. All rights reserved.
//

import UIKit
import Alamofire

class CWHTTPSessionManager: Manager {

    
    
}
